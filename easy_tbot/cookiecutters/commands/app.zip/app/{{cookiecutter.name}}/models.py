from easy_tbot.db.alchemy.shorcuts import Model
from sqlalchemy import Column, Integer, String

# Write your models here

class TestModel(Model):
    '''A sample purpose model'''
    
    __tablename__='test'
    id = Column(Integer, primary_key=True)
    some_field = Column(String)
