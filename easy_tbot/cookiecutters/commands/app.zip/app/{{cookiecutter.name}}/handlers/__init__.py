# You cant split your handlers in diferents modules and import that modules here

from .messages import *