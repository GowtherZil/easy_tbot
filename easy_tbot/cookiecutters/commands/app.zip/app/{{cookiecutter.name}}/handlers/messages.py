from easy_tbot.bot.decorators import message_handler
from aiogram.types import Message

# write your handlers here

@message_handler()
async def hello_world(msg:Message, **kwargs):
    '''A sample purpose handler'''
    await msg.reply('hello world!!!')
