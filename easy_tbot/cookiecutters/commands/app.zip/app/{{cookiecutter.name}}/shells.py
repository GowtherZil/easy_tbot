from easy_tbot.shell.custom import ShellCommand

# Write your shell here
class HelloWorldCommand(ShellCommand):
    '''A sample purpose shell'''

    name='hello_world'
    extra={'help':'A sample purpose command'}

    def do(self, *args, **kwargs):
        print('Hello World!!')
