from easy_tbot.bot.aiogram.backend import AiogramBackend
from easy_tbot.db.alchemy.backend import SqlAlchemyBackend
from easy_tbot.render.jinja.backend import Jinja
from easy_tbot.shell.custom.backend import ShellBackend
from pathlib import Path

BASE_DIR = Path(__file__).parent

BOT={
    'backend': AiogramBackend,
    'config': {
        'token':''
        }
}

DB={
    'backend': SqlAlchemyBackend,
    'config': {
        'url':'sqlite:///./sqlite.db'
        }
}

TEMPLATE_ENGINE={
    'backend': Jinja,
    'config': {
        'templates':[ BASE_DIR / 'templates'],
        'allowed_extensions':['html', 'md', 'txt']
        }
}

SHELL={
    'backend': ShellBackend,
    'config': {}
}


FRAGMENTS= [
    'easy_tbot.bot.commands',
    'easy_tbot.db.alchemy.commands',
    'easy_tbot.cookiecutters.commands',
    ]

# Uncoment for loggin
# import logging
# logging.basicConfig(level=logging.DEBUG)

